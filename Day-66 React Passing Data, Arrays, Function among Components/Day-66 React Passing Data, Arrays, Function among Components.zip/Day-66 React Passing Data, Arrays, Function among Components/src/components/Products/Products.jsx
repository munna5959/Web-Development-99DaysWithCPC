import React from 'react'
import './Products.css'

const Products = (props) => {
    console.log(props.phone)
    console.log(props.buy)
  return (
    <div className="products-div">
        <h3>Product Name: {props.phone.name}</h3>
        <p>Product Price: {props.phone.price}</p>
        <button onClick={props.buy}>Buy Now</button>
    </div>
  )
}

export default Products
