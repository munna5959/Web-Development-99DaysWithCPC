import './App.css'
import Products from './components/Products/Products'

function App() {

  const products = [
    {
      name: 'Samsung Galaxy S21',
      price: 1000
    },
    {
      name: 'iPhone 12',
      price: 1200
    },
    {
      name: 'Google Pixel 5',
      price: 800
    }
  ];

  function forBuy() {
    alert('You have bought the product');
  }

  return (
    <>
          {
              products.map(product => 
                <Products
                  phone = {product}
                  buy = {forBuy}
              ></Products>
              )
          }       
    </>
      
  )
}

export default App
