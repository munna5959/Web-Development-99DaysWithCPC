import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import HomePage from './components/HomePage/HomePage.jsx'
import About from './components/About/About.jsx'
import Contract from './components/Contract/Contract.jsx'
import './index.css'
import App from './App.jsx'
import {createBrowserRouter,RouterProvider} from 'react-router-dom' 
import Products from './components/Products/Products.jsx'
import More from './components/More/More.jsx'

const router = createBrowserRouter([
 {
  path:'/',
  element:<App></App>,
  children:
   [
    {
      path:'/home',
      element:<HomePage></HomePage>
     },
     {
       path:'/about',
        element:<About></About>
     },
     {
      path:'/contact',
      element: <Contract></Contract>
     },
     {
      path: '/products',
      loader: () => fetch('https://fakestoreapi.com/products'),
      element: <Products></Products>
     },
     {
      path:'/products/:productID',
      loader: ({params}) => fetch(`https://fakestoreapi.com/products/${params.productID}`),
      element: <More></More>
     }
   ]
 },

]);



createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider
     router={router}
    ></RouterProvider> 
  </StrictMode>,
)
