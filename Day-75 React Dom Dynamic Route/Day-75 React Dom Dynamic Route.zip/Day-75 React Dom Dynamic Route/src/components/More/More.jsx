import React from 'react'
import { useLoaderData } from 'react-router-dom'
import './More.css'

const More = () => {
  const moreInfo = useLoaderData();
  return (
    <div className='main'>
               <div className="card">
               <img src={moreInfo.image} alt="" />
               <div className="text-content">
                  <h3>{moreInfo.title}</h3>
                  <h2>{moreInfo.price}</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quas obcaecati quod veritatis aliquam corrupti?</p>
               </div>
              
            </div>
            
      </div>
  )
}

export default More
