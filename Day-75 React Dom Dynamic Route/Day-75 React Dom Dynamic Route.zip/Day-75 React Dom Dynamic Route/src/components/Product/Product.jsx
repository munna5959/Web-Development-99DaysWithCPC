import React from 'react'
import './Product.css'
import { Link } from 'react-router-dom'

const Product = ({product}) => {
  const {title,image, price,description} = product
  return (
      <div className='main'>
               <div className="card">
               <img src={image} alt="" />
               <div className="text-content">
                  <h3>{title}</h3>
                  <h2>{price}</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quas obcaecati quod veritatis aliquam corrupti?</p>
               </div>
               <Link to={`/products/${product.id}`}><button className='btn-info'>More info</button></Link>
              
            </div>
            
      </div>
  )
}

export default Product