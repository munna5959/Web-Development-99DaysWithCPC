import React, { useState } from 'react';

const ConditionalStyle = () => {
    const [isSpecial, setIsSpecial] = useState(false);

    const commonStyle = {
        margin: '0px',
        padding: '10px',
        border: '1px solid red',
        backgroundColor: isSpecial ? 'yellow' : 'white', 
        color: isSpecial ? 'blue' : 'black'
    }

    const toggleBtn = () => {
        setIsSpecial(!isSpecial);
    }

    return (
        <div>
            <button onClick={toggleBtn}>Make it {isSpecial ? 'Normal' : 'Special'}</button>
            <div>
                <h3 style={commonStyle}>This is {isSpecial ? 'Special' : 'Normal'}</h3>
            </div>
        </div>
    );
};

export default ConditionalStyle
