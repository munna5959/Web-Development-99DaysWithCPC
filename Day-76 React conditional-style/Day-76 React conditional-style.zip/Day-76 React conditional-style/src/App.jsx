import './App.css'
import ConditionalStyle from './components/ConditionalStyle/ConditionalStyle'

function App() {
  

  return (
    <div>
        <ConditionalStyle></ConditionalStyle>
    </div>
  )
}

export default App
