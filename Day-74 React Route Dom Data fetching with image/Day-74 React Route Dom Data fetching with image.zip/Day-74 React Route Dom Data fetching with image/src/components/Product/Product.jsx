import React from 'react'
import './Product.css'

const Product = ({product}) => {
  const {title,image, price,description} = product
  return (
       <div className="card">
          <img src={image} alt="" />
          <div className="text-content">
             <h3>{title}</h3>
              <h2>{price}</h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quas obcaecati quod veritatis aliquam corrupti?</p>
          </div>
       </div>
  )
}

export default Product