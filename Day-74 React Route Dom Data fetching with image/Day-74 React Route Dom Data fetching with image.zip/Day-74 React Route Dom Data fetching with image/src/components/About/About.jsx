import React from 'react';
import './About.css';

const About = () => {
  return (
    <div>
        
        <section className="container">
            <h2>About Us</h2>
            <div className="about-content">
                <div className="about-text">
                    <p>Welcome to Programming Easy! We are dedicated to making programming accessible and enjoyable for everyone. Whether you're a beginner or an experienced developer, we have something for you. Our tutorials, articles, and resources are designed to help you learn and grow in your programming journey.</p>
                    <p>Our mission is to provide high-quality content that is easy to understand and apply. We believe that learning to code should be a fun and rewarding experience, and we are here to support you every step of the way.</p>
                    <p>Join our community and start your programming adventure with us today!</p>
                </div>
                <div className='about-photo'>
                <h2>Content photo</h2>
                </div>
            </div>
        </section>
    </div>
  )
}

export default About;
