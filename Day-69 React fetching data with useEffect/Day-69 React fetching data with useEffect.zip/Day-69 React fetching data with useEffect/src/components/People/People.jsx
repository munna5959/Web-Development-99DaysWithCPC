import React from 'react'
import './People.css' 

const People = (props) => {

  return (
    <div className='main-container'>
        <h2>{props.peopleData.name}</h2>
        <div className="people">
            <h3>Phone:{props.peopleData.phone}</h3>
            <h3>Email:{props.peopleData.email}</h3>
        </div>        
    </div>
  )
}

export default People
