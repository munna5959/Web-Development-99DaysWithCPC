import { useEffect, useState } from 'react'
import './App.css'
import People from './components/People/People'

function App() {
  const [allData, setAllData] = useState([]);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(data => setAllData(data))
  }, [])

  return (
   <div>
      {
        allData.map(peopleData => <People
        key = {peopleData.id}
        peopleData={peopleData}
        ></People>)
      }
   </div>
  )
}

export default App
