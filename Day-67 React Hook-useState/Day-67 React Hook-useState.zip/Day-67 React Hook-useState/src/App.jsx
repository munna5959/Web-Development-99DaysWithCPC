import './App.css'
import { useState } from 'react'

function App() {

  let [price, setPrice] = useState(0);

  const increamentHandler = () => {
    const newPrice = price + 1;
    setPrice(newPrice);
  }
  const decreamentHandler = () => {
    const newPrice = price - 1;
    setPrice(newPrice);
  }
  


  return (
    <div>
      <h1>The Price is: {price}</h1>
      <button onClick={increamentHandler}>Increament</button>&nbsp;&nbsp;&nbsp;
      <button onClick={decreamentHandler}>Decreament</button>
      <h2>The Price is: {price}</h2>
      <h3>The Price is: {price}</h3>
    </div>
      
  )
}

export default App
