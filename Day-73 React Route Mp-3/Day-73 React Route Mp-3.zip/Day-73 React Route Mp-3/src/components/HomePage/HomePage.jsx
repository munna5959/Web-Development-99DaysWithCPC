import React from 'react';
import './HomePage.css';

const HomePage = () => {
  return (
    <div className='homepage'>
      <header className='header'>
        <h1>Welcome to Programming Easy</h1>
        <p>Your go-to resource for learning programming effortlessly.</p>
      </header>
      <main className='content'>
        <h2>Learn Programming with Ease</h2>
        <p>Explore our tutorials, guides, and resources to become a proficient programmer.</p>
      </main>
      <footer className='footer'>
        <p>&copy; 2025 Programming Easy. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default HomePage;
