import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [count, setCount] = useState(0);
  alert('Component is mounted & value changed');

  useEffect(() => {
    document.title = `You clicked ${count} times`;

    return () => {
      document.title = 'React App';
    };
  }, [count]); 

  return (
    <div>
      <h2>You clicked {count} times</h2>
      <button onClick={() => setCount(count + 1)}>Click me</button>
    </div>
  );
}

export default App;
