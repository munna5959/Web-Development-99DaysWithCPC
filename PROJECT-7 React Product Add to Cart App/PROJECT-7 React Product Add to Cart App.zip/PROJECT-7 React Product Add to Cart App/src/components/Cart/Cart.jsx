import React from 'react'
import './Cart.css'

const Cart = ({cart}) => {

  return (
    <div className='cart'>
        <h2>Added Items</h2>
       {
        cart.map(singleData => <h3 className='name'>{singleData.name} is added on cart</h3>)
       }
    </div>
  )
}

export default Cart
