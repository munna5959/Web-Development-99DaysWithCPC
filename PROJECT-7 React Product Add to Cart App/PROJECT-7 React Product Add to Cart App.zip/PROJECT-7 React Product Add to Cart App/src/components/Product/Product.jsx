import React from 'react'
import './Product.css'

const Product = ({product, addToCart} ) => {

    const {name, price, description} = product;



  return (
    <div className="product">
        <h2>Name: {name}</h2>
        <p>Price: {price}</p>
        <p>Description: {description}</p>
        <button onClick={() => addToCart(product)}>Add To Cart</button>
    </div>
  )
}

export default Product