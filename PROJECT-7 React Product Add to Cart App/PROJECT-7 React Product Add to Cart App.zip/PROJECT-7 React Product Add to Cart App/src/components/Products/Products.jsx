import React, { useState } from 'react'
import { useEffect } from 'react'
import Product from '../Product/Product'    
import './Products.css'

const Products = ({addToCart}) => {

    const [products , setProducts]= useState([]);

    useEffect(() => {
        fetch('myData.json')
        .then(res => res.json())
        .then(data => setProducts(data))

    }, [])

  return (
    <div className='products'>
       {
            products.map(product => <Product
                key={product.id}
                product={product}
                addToCart={addToCart}
            ></Product>)
       }
    </div>
  )
}

export default Products
