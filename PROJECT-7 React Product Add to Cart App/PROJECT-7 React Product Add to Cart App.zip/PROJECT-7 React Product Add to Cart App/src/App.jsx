
import './App.css'
import Products from './components/Products/Products'
import Cart from './components/Cart/Cart'
import { useState } from 'react'

function App() {
  const [cart, setCart] = useState([]);

function addToCart(product) {
    const newCart= [...cart, product];
    setCart(newCart);
}

  return (
    <div className='app'>
        <Products
        addToCart={addToCart}
        
        ></Products>
        <Cart
        key={cart.id}  
        cart={cart}
        ></Cart>
    </div>

  )
}

export default App
