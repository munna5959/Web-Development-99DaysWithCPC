import React from 'react'

const Newnav = () => {
  return (
    <div>
        <button>Newnav is</button>
    </div>
  )
}

export default Newnav