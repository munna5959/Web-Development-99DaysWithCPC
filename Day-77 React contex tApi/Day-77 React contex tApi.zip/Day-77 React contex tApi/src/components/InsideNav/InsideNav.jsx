import React from 'react'
import Newnav from '../Newnav/Newnav'

const InsideNav = () => {
  return (
    <div>
        <Newnav></Newnav>
       <button>Inside Nav is </button>
    </div>
  )
}

export default InsideNav