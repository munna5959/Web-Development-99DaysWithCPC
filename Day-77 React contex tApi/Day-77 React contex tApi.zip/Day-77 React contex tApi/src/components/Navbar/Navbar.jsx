import React from 'react'
import InsideNav from '../InsideNav/InsideNav'

const Navbar = () => {
  return (
    <div>
        <InsideNav></InsideNav>
        <button>Nav Count is </button>
    </div>
  )
}

export default Navbar